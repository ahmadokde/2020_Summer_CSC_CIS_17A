/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Blackjack.h
 * Author: Ahmad okde
 *
 * Created on 13 July, 2020, 4:26 PM
 */

#ifndef BLACKJACK_H
#define BLACKJACK_H

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <string.h>
using namespace std;

char WinnerFileName[] = "winners.bin";
const int NUM_OF_CARDS = 52;
const int MAX_CARDS = 12;
const int MAX_PLAYERS = 5;
const int MAX_HANDS = 4;


enum status { Not_Used = -1, FIRST, HIT, SURRENDER, STAND, DOUBLE, BUST };
struct DeckOfCards {
	int* deck;
	int index;
	int size;
};

struct Winner
{
	string name;
	string status;
};

struct Hand {
	int cards[MAX_CARDS];
	int index;
	int bet;
	status Stat; // keeps track
};
struct Player {
	Hand hand[MAX_HANDS];
	int numhands;
};
struct BlackJack {
	Hand Dealer;
	Player Players[MAX_PLAYERS];
	int numplayers;
	int* Deck;
	int index;
	int decksize;
};

int displayMenu();
void WriteToBinaryFile(BlackJack BJ, string players_name[]);
void initializePlayer(Player& P);
void initializeHand(Hand& H);
void startGame(BlackJack& BJ, int);
void displayResult(BlackJack BJ, string players_name[]);
void DealerPlay(BlackJack& BJ);
void Shuffle(BlackJack&);
void printGame(BlackJack& BJ, bool flag, string players_name[]);
void continuePlay(BlackJack& BJ, int player, string players_name[]);
void firstplay(BlackJack& BJ, int player, int h, string players_name[]);
void itoa(int n, char s[]);
void reverse(char* s);
char* getcard(int card, char* str);
void initializeDeck(BlackJack& BJ);
char getSuit(int card);
int DealCard(BlackJack& game);
void firstDeal(BlackJack& game);
void printHand(Hand hand);
int CountCards(Hand H);
int CardValue(int card);
void initializeGame(BlackJack& BJ);


int displayMenu()
{
	int option;
	cout << "\n\n1. Play Game\n";
	cout << "2. Check Winner Statistics\n";
	cout << "0. Exit\n";
	cout << "Enter option: ";
	cin >> option;
	while (option < 0 || option>2)
	{
		cout << "ERROR: Enter a valid option\n\n";
		cout << "Enter option: ";
		cin >> option;
	}
	return option;
}



void initializeDeck(BlackJack& BJ)
{
	BJ.Deck = new int[NUM_OF_CARDS];
	BJ.decksize = NUM_OF_CARDS;
	for (int c = 0; c < NUM_OF_CARDS; c++) {
		BJ.Deck[c] = c;
	}
	BJ.index = 0;
}




void Shuffle(BlackJack& game)
{
	int n;
	int temp;

	for (int c = 0; c < game.decksize; c++) {
		n = (int)(rand() % 52);
		temp = game.Deck[c];
		game.Deck[c] = game.Deck[n];
		game.Deck[n] = temp;
	}
	game.index = 0;
}



char getSuit(int card)
{
	if (card < 13 && card >= 0)
		return 'S';
	else if (card < 26 && card >= 0)
		return 'C';
	else if (card < 39 && card >= 0)
		return 'H';
	else if (card < 52 && card >= 0)
		return 'D';
	return '\0';
}




char* getcard(int card, char* str)
{
	if (card % 13 == 0) {
		str[0] = 'A';
		str[1] = '\0';
	}
	else if (card % 13 >= 1 && card % 13 < 9)
		itoa(card % 13 + 1, str);
	else if (card % 13 == 9) {
		str[0] = '1';
		str[1] = '0';
		str[2] = '\0';
	}
	else if (card % 13 == 10) {
		str[0] = 'J';
		str[1] = '\0';
	}
	else if (card % 13 == 11) {
		str[0] = 'Q';
		str[1] = '\0';
	}
	else if (card % 13 == 12) {
		str[0] = 'K';
		str[1] = '\0';
	}
	else {
		str[0] = '\0';
	}
	return str;
}




void firstDeal(BlackJack& game)
{
	const int NUMPLAYERS = game.numplayers;

	for (int c = 0; c < NUMPLAYERS; c++)
		game.Players[c].hand[0].cards[0] = DealCard(game);
	game.Dealer.cards[0] = DealCard(game);
	for (int i = 0; i < NUMPLAYERS; i++) {
		game.Players[i].hand[0].cards[1] = DealCard(game);
		game.Players[i].numhands = 1;
		game.Players[i].hand[0].index = 2;
		game.Players[i].hand[0].Stat = FIRST;
	}
	game.Dealer.cards[1] = DealCard(game);
	game.Dealer.index = 2;

}



void printHand(Hand hand)
{
	char str[3];
	for (int c = 0; c < hand.index; c++) {
		cout << getcard(hand.cards[c], str) << getSuit(hand.cards[c]);
		cout << " ";
	}
	cout << " :" << CountCards(hand) << " ";

}




int DealCard(BlackJack& BJ)
{
	int card = BJ.Deck[BJ.index];
	BJ.index++;
	return card;
}



int CardValue(int card)
{
	char* str = new char[3];
	int i = 0;

	str = getcard(card, str);

	if (str[0] == 'A')
		i = 11;
	else if (str[0] == 'J' || str[0] == 'Q' || str[0] == 'K')
		i = 10;
	else if (str[0] >= '1' && str[0] <= '9')
		i = (int)atoi(str);
	else
		i = -1;
	delete[] str;
	return i;
}



void initializeGame(BlackJack& BJ)
{
	for (int i = 0; i < MAX_CARDS; i++)
		BJ.Dealer.cards[i] = -1; //Sets all the cards in the Dealers hand.
	BJ.Dealer.Stat = FIRST;	//Sets the Status to first card.

	for (int c = 0; c < MAX_PLAYERS; c++) //Initializes each player.
		initializePlayer(BJ.Players[c]);
	initializeDeck(BJ);

}


void initializePlayer(Player& P)
{
	P.numhands = 0; // Sets number of hands the player has to zero.
	for (int c = 0; c < MAX_HANDS; c++) 	// Initializes each possible hand in the
		initializeHand(P.hand[c]);			// a player structure.
}


void initializeHand(Hand& H)
{
	int i;
	for (i = 0; i < MAX_CARDS; i++) // Sets each card to -1.
		H.cards[i] = -1;
	H.Stat = Not_Used; // Sets status flag to not used.
	H.bet = 0;
	H.index = 0;
}

void startGame(BlackJack& BJ, int numplayers)
{
	BJ.numplayers = numplayers;
	firstDeal(BJ);
}


int CountCards(Hand H)
{
	int accum = 0;
	int aces = 0;
	int c = 0;

	for (c = 0; c < H.index; c++) {
		if (CardValue(H.cards[c]) == 11)
			aces++;
		if (CardValue(H.cards[c]) < 1)

			return -1;
		accum += CardValue(H.cards[c]);
	}
	while (accum > 21 && aces > 0) {
		accum -= 10; //subtracts 10 for an ace.
		aces--;
	}


	return accum;
}

void printGame(BlackJack& BJ, bool flag, string players_name[])
{
	char str[3];

	cout << "Dealers: ";
	if (flag == false)
		cout << getcard(BJ.Dealer.cards[0], str) << getSuit(BJ.Dealer.cards[0]);
	else
		printHand(BJ.Dealer);
	cout << endl << endl;

	for (int i = 0; i < BJ.numplayers; i++) {
		cout << "Player " << players_name[i] << endl;
		for (int c = 0; c < BJ.Players[i].numhands; c++) {

			cout << "hand #" << c + 1 << " ";
			printHand(BJ.Players[i].hand[c]);
			if (BJ.Players[i].hand[c].Stat == FIRST)
				cout << "start of hand.";
			else if (BJ.Players[i].hand[c].Stat == SURRENDER)
				cout << "Surrender";
			else if (BJ.Players[i].hand[c].Stat == STAND)
				cout << "Stand";
			else if (BJ.Players[i].hand[c].Stat == BUST)
				cout << "Bust";
			else if (BJ.Players[i].hand[c].Stat == DOUBLE)
				cout << "Double down.";
			cout << endl;
		}
	}
}

void firstplay(BlackJack& BJ, int player, int h, string players_name[])
{
	char str[3], arg[3];
	char ch;
	bool can_split = false;
	bool loop;
	int index = BJ.Players[player].numhands;


	printGame(BJ, false, players_name);
	if (CountCards(BJ.Players[player].hand[h]) == 21) {
		cout << "BlackJack!" << endl;
	}
	else if (strcmp(getcard(BJ.Players[player].hand[h].cards[0], str),
		getcard(BJ.Players[player].hand[h].cards[1], arg)) == 0) {
		if (index < MAX_HANDS)
			can_split = true;
		else
			can_split = false;
	}
	cout << "Player " << players_name[player]
		<< " type 'H' to Hit, 'S' to Stand, 'D' to Double Down, ";
	if (can_split == true) {
		cout << "'U' to Surrender, and 'P' to Split: ";
	}
	else {
		cout << "and 'U' to Surrender: ";
	}
	do {
		ch = cin.get();
		switch (toupper(ch)) {
		case 'H':
			BJ.Players[player].hand[h].Stat = HIT;
			BJ.Players[player].hand[h].cards[2] = DealCard(BJ);
			BJ.Players[player].hand[h].index++;
			if (CountCards(BJ.Players[player].hand[0]) > 21)
				BJ.Players[player].hand[h].Stat = BUST;
			loop = false;
			break;
		case 'S':
			BJ.Players[player].hand[h].Stat = STAND;
			loop = false;
			break;
		case 'D':
			BJ.Players[player].hand[h].Stat = DOUBLE;
			BJ.Players[player].hand[h].cards[2] = DealCard(BJ);
			BJ.Players[player].hand[h].index++;
			if (CountCards(BJ.Players[player].hand[h]) > 21)
				BJ.Players[player].hand[h].Stat = BUST;
			loop = false;
			break;
		case 'U':
			BJ.Players[player].hand[h].Stat = SURRENDER;
			loop = false;
			break;
		case 'Q':
			delete BJ.Deck;
			exit(0);
		default:
			if (toupper(ch) == 'P' && can_split == true) {
				BJ.Players[player].hand[index].cards[0]
					= BJ.Players[player].hand[0].cards[1];
				BJ.Players[player].hand[h].cards[1] = DealCard(BJ);
				BJ.Players[player].hand[index].cards[1]
					= DealCard(BJ);
				BJ.Players[player].hand[h].Stat = FIRST;
				BJ.Players[player].hand[index].Stat = FIRST;
				BJ.Players[player].numhands = 2;
				BJ.Players[player].hand[index].index = 2;
				loop = false;
			}
			else {
				cout << "invalid choice try again: " << endl;
				loop = true;
			}
		}
		cin.ignore();
	} while (loop == true);
	return;

}

void continuePlay(BlackJack& BJ, int player, string players_name[])
{
	int total;
	char ch;
	bool loop = true;
	int hands = BJ.Players[player].numhands;
	int i = 0, test = hands;

	do {
		hands--;
		firstplay(BJ, player, i, players_name);
		if (test < BJ.Players[player].numhands) {
			test = BJ.Players[player].numhands;
			hands++;
		}
		if (BJ.Players[player].hand[i].Stat == STAND ||
			BJ.Players[player].hand[i].Stat == BUST ||
			BJ.Players[player].hand[i].Stat == DOUBLE ||
			BJ.Players[player].hand[i].Stat == SURRENDER) {
			if (i == BJ.Players[player].numhands)
				return;
			else
				i++;

		}
		else {

			do {
				printGame(BJ, false, players_name);
				total = CountCards(BJ.Players[player].hand[i]);
				cout << "Player " << players_name[player] << " hand #" << i + 1;
				if (total == 21) {
					cout << " is 21." << endl;
				}
				else if (total > 21) {
					cout << " is bust." << endl;
					loop = false;
				}
				cout << " type 'H' to Hit, and 'S' to STAND: " << endl;
				ch = cin.get();
				if (toupper(ch) == 'H') {
					BJ.Players[player].hand[i].cards[BJ.Players[player].hand[i].index] = DealCard(BJ);
					BJ.Players[player].hand[i].index++;
					if (CountCards(BJ.Players[player].hand[i]) > 21) {
						BJ.Players[player].hand[i].Stat = BUST;
						loop = false;
					}
					else {
						loop = true;
						BJ.Players[player].hand[i].Stat = HIT;
					}
				}
				else if (toupper(ch) == 'S') {
					BJ.Players[player].hand[i].Stat = STAND;
					loop = false;
				}
				else if (toupper(ch) == 'Q') {
					exit(0);
				}
				if (CountCards(BJ.Players[player].hand[i]) > 21) {
					BJ.Players[player].hand[i].Stat = BUST;
					cout << "Player #" << player + 1 << " hand #"
						<< i + 1 << " is bust!" << endl;
					loop = false;
				}
				cin.ignore();
			} while (loop == true);

			i++;
		}
	} while (hands > 0);

}
void DealerPlay(BlackJack& BJ) {


	while (CountCards(BJ.Dealer) < 17) {
		BJ.Dealer.cards[BJ.Dealer.index] = DealCard(BJ);
		BJ.Dealer.index++;
		BJ.Dealer.Stat = HIT;
	}
	if (CountCards(BJ.Dealer) > 21)
		BJ.Dealer.Stat = BUST;
	else
		BJ.Dealer.Stat = STAND;

}
void displayResult(BlackJack BJ, string players_name[])
{
	bool DealerBust = false;;

	system("cls");
	cout << "Dealers: ";
	printHand(BJ.Dealer);
	if (CountCards(BJ.Dealer) > 21) {
		cout << "BUST";
		DealerBust = true;
	}
	cout << endl << endl;

	for (int i = 0; i < BJ.numplayers; i++) {
		cout << "Player " << players_name[i] << endl;;
		for (int c = 0; c < BJ.Players[i].numhands; c++) {
			cout << "hand #" << c + 1 << " ";
			printHand(BJ.Players[i].hand[c]);
			if (BJ.Players[i].hand[c].Stat == SURRENDER)
				cout << "lose";
			else if (CountCards(BJ.Players[i].hand[c])
				<= 21 && DealerBust == true)
				cout << "WIN!";
			else if (CountCards(BJ.Players[i].hand[c]) > 21)
				cout << "lose";
			else if (CountCards(BJ.Players[i].hand[c])
				== CountCards(BJ.Dealer))
				cout << "Push";
			else if (CountCards(BJ.Players[i].hand[c])
				< CountCards(BJ.Dealer)
				&& DealerBust == false)
				cout << "lose";
			else if (CountCards(BJ.Players[i].hand[c])
				> CountCards(BJ.Dealer) &&
				CountCards(BJ.Players[i].hand[c]) <= 21)
				cout << "WIN";
			cout << endl;
		}
	}
}
void WriteToBinaryFile(BlackJack BJ, string players_name[])
{

	ofstream output(WinnerFileName, ios::out | ios::app | ios::binary);
	if (!output) {
		cout << "Cannot open file!" << endl;
		return;
	}
	bool DealerBust = false;;
	char str[3];


	for (int i = 0; i < BJ.numplayers; i++)
	{
		Winner player;
		player.name = players_name[i];
		for (int c = 0; c < BJ.Players[i].numhands; c++) {


			if (BJ.Players[i].hand[c].Stat == SURRENDER)
				player.status = "lose";
			else if (CountCards(BJ.Players[i].hand[c])
				<= 21 && DealerBust == true)
				player.status = "WIN!";
			else if (CountCards(BJ.Players[i].hand[c]) > 21)
				player.status = "lose";
			else if (CountCards(BJ.Players[i].hand[c]) == CountCards(BJ.Dealer))
				player.status = "Push";
			else if (CountCards(BJ.Players[i].hand[c]) < CountCards(BJ.Dealer) && DealerBust == false)
				player.status = "lose";
			else if (CountCards(BJ.Players[i].hand[c]) > CountCards(BJ.Dealer) &&
				CountCards(BJ.Players[i].hand[c]) <= 21)
				player.status = "WIN";
		}
		output.write((char*)&player, sizeof(Winner));
	}
	output.close();

}
/*
 * Function itoa();
 * From The C programming language Second Edition
 * Brian w. Kernighan and Dennis M Ritchie
 *
 */
void itoa(int n, char s[])
{
	int i, sign;

	if ((sign = n) < 0) /* record sign */
		n = -n;
	i = 0;
	do {
		s[i++] = n % 10 + '0';
	} while ((n /= 10) > 0);
	if (sign < 0)
		s[i++] = '-';
	s[i] = '\0';
	reverse(s);
}
/*
 * Function reverse()
 * From The C programming language Second Edition
 * Brian w. Kernighan and Dennis M Ritchie
 */
void reverse(char* s)
{
	int c, i, j;

	for (i = 0, j = strlen(s) - 1; i < j; i++, j--) {
		c = *(s + i);
		*(s + i) = *(s + j);
		*(s + j) = c;
	}
}


#endif /* BLACKJACK_H */


