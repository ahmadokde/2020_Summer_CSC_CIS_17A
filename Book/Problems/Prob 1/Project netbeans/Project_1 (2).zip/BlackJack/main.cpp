/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Ahmad.Okde
 *
 * Created on July 13, 2020, 3:16 PM
 */

#include "Blackjack.h"

int main()
{
	srand(time(NULL));
	string* players_name;
	int option = displayMenu();
	while (option != 0)
	{
		switch (option)
		{
		case 1: //play game
		{
			BlackJack game;
			int numplayers;
			char ch;
		
			initializeGame(game); // Initialize the deck and players.
			Shuffle(game);	// Shuffles deck of cards.
			cout << "Enter the number of players (between 1 and 5)?";
			cin >> numplayers; // Gets number of players
			while (numplayers < 1 || numplayers > 5) {
				cout << "ERROR: Invalid number of players. Try again: ";
				cin >> numplayers;
			}
			players_name = new string[numplayers];
			cin.ignore();
			for (int i = 0; i < numplayers; i++)
			{
				cout << "Enter player " << (i + 1) << " name: ";
				getline(cin, players_name[i]);
			}

			startGame(game, numplayers);
			for (int c = 0; c < game.numplayers; c++) {
				continuePlay(game, c, players_name);
			}
			DealerPlay(game);
			displayResult(game, players_name);
			WriteToBinaryFile(game, players_name);
			delete game.Deck;
		}
		break;
		case 2: //display statistics
		{
			ifstream input(WinnerFileName, ios::in | ios::binary);
			if (!input) {
				cout << "Cannot open file!" << endl;
			}
			else
			{
				Winner win;
				while (!input.eof())
				{
					input.read((char*)&win, sizeof(Winner));
					cout << win.name << " " << win.status << endl;
					if (!input) 
						break;
				}
			}
			input.close();
		}
		
		}
		option = displayMenu();
	}
}

