var searchData=
[
  ['double_158',['Double',['../namespace_blackjack.html#a2a5d8dd0adf01f81a5c6b4d2f4f8bf9ba2f4a70c94efe0053c962cf4d7909fce5',1,'Blackjack']]]
];
