var searchData=
[
  ['first_159',['first',['../namespace_blackjack.html#a2a5d8dd0adf01f81a5c6b4d2f4f8bf9ba0f210ca8e9ede92815e1b2865a8ade0e',1,'Blackjack']]]
];
