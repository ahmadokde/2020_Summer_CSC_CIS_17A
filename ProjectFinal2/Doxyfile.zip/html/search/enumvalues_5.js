var searchData=
[
  ['stand_162',['Stand',['../namespace_blackjack.html#a2a5d8dd0adf01f81a5c6b4d2f4f8bf9ba5c2244f09441033222545b695943774b',1,'Blackjack']]],
  ['surrender_163',['Surrender',['../namespace_blackjack.html#a2a5d8dd0adf01f81a5c6b4d2f4f8bf9baac39e356710e0f50d759138a9fd4e8b4',1,'Blackjack']]]
];
