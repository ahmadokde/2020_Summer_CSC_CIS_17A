var searchData=
[
  ['blackjack_88',['Blackjack',['../namespace_blackjack.html',1,'']]]
];
